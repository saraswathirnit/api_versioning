package com.kafka.company1consumer.service;

import com.kafka.company1consumer.dto.TicketEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class TicketEventConsumer {

    // 🔹 Listen to messages from Company2 (main messages)
    @KafkaListener(
            topics = "${app.topic.consume1}",
            groupId = "company1-consumer-group",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeFromCompany2(TicketEvent event) {
        System.out.println("=== Company1 Chat Window ===");
        System.out.println("From company: " + event.getCompany());
        System.out.println("Project: " + event.getProject());
        System.out.println("TicketId: " + event.getTicketId());
        System.out.println("Message: " + event.getData());
        System.out.println("=====================================");
    }

    // 🔹 Listen to replies from Company2
    @KafkaListener(
            topics = "${app.topic.consume2}",
            groupId = "company1-consumer-group",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeRepliesFromCompany2(TicketEvent event) {
        System.out.println("=== Company1 Reply Window ===");
        System.out.println("Reply from: " + event.getCompany());
        System.out.println("Project: " + event.getProject());
        System.out.println("TicketId: " + event.getTicketId());
        System.out.println("Message: " + event.getData());
        System.out.println("=====================================");
    }
}
