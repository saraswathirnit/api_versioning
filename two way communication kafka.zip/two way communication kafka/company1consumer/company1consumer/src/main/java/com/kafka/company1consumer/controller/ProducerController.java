package com.kafka.company1consumer.controller;

import com.kafka.company1consumer.dto.TicketEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/Company1")  // 👈 Base path becomes http://localhost:8080/Company1
public class ProducerController {

    private final KafkaTemplate<String, TicketEvent> kafkaTemplate;

    @Value("${app.topic.produce2}")   // Kafka topic (already in your properties)
    private String requestTopic;

    public ProducerController(KafkaTemplate<String, TicketEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    // 👇 POST to http://localhost:8080/Company1
    @PostMapping
    public String produceMessage(@RequestBody String message) {
        TicketEvent event = new TicketEvent();
        event.setCompany("Company1");
        event.setProject("ProjectFromCompany1");
        event.setTicketId("ticket-" + UUID.randomUUID());
        event.setData(message);

        // 🚀 Send to Company2’s Kafka topic
        kafkaTemplate.send(requestTopic, event);

        return "✅ Sent via REST API (Company1): " + message;
    }
}
