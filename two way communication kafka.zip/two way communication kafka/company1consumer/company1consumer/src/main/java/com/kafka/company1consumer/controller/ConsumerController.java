/*package com.kafka.company1consumer.controller;

import com.kafka.company1consumer.dto.TicketEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/reply")
public class ConsumerController {

    private final KafkaTemplate<String, TicketEvent> kafkaTemplate;

    public ConsumerController(KafkaTemplate<String, TicketEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @PostMapping
    public String sendReply(@RequestBody String message) {
        TicketEvent reply = new TicketEvent();
        reply.setCompany("Company1");
        reply.setProject("Project1");
        reply.setTicketId("reply-" + UUID.randomUUID());
        reply.setData(message);

        kafkaTemplate.send("company1-reply-topic", reply);

        return "✅ Reply sent to Producer via Kafka: " + message;
    }
}*/
