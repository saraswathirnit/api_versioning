package com.kafka.company2producer.util;
/*package com.kafka.company2producer;

import com.kafka.company2producer.dto.TicketEvent;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;
import java.util.UUID;

@Component
public class ConsoleProducer implements CommandLineRunner {

    private final ProducerService producerService;

    public ConsoleProducer(ProducerService producerService) {
        this.producerService = producerService;
    }

    @Override
    public void run(String... args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Console Producer Started ===");
        System.out.println("Type messages here. Each line will be sent to Kafka. Type 'exit' to quit.");

        while (true) {
            String line = scanner.nextLine();
            if ("exit".equalsIgnoreCase(line)) {
                System.out.println("Exiting producer console...");
                break;
            }

            // Create dummy event with console input
            TicketEvent event = new TicketEvent(
                    "Company2",
                    "ProjectConsole",
                    "ticket-" + UUID.randomUUID(),
                    line
            );

            // ✅ unified method
            producerService.sendEvent(event);
        }
    }
}
*/