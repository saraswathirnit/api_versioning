package com.kafka.company2producer;

import com.kafka.company2producer.dto.TicketEvent;
import com.kafka.company2producer.listener.ProducerService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Company2producerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Company2producerApplication.class, args);
    }

    // ✅ Auto-run producer once the app starts
    @Bean
    public CommandLineRunner runner(ProducerService producerService) {
        return args -> {
            TicketEvent event = new TicketEvent(
                    "Company2",
                    "Project4",
                    "ticket-3",
                    "Auto-triggered data from Company2 -> Project4"
            );

            // ✅ uses sendEvent (standardized)
            producerService.sendEvent(event);
        };
    }
}
