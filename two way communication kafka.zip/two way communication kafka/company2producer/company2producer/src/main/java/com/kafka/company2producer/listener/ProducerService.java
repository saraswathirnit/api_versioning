package com.kafka.company2producer.listener;

import com.kafka.company2producer.dto.TicketEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ProducerService {

    private final KafkaTemplate<String, TicketEvent> kafkaTemplate;

    public ProducerService(KafkaTemplate<String, TicketEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    // ✅ Only send the event and log a simple confirmation
    public void sendEvent(TicketEvent event) {
        kafkaTemplate.send("company-topic", event.getTicketId(), event);
        System.out.println("✅ Sent to Kafka (Company2): " + event.getData());
    }
}

