package com.kafka.company2producer.controller;

import com.kafka.company2producer.dto.TicketEvent;
import com.kafka.company2producer.listener.ProducerService; // ✅ keep as-is if your class really lives in listener

import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/Company2")   // 👈 Base URL now http://localhost:8081/Company2
public class ProducerController {

    private final ProducerService producerService;

    public ProducerController(ProducerService producerService) {
        this.producerService = producerService;
    }

    // ✅ POST http://localhost:8081/Company2
    @PostMapping
    public String sendMessage(@RequestBody String message) {
        TicketEvent event = new TicketEvent(
                "Company2",                  // company name
                "ProjectFromCompany2",       // project name
                "ticket-" + UUID.randomUUID(), // unique ticket id
                message                       // data (send or reply)
        );

        // 🚀 Forward message to Kafka (Company1 will consume it)
        producerService.sendEvent(event);

        return "✅ Sent via REST API (Company2): " + message;
    }
}
