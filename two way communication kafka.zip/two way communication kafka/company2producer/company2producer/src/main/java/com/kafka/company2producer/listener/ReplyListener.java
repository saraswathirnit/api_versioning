/*package com.kafka.company2producer.listener;

import com.kafka.company2producer.dto.TicketEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class ReplyListener {

    // 🔹 Listen to replies from Company1
    @KafkaListener(
        topics = "${app.topic.consume1}",   // ✅ uses property binding
        groupId = "company2-producer-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void listenRepliesFromCompany1(TicketEvent event) {
        System.out.println("=== Company2 Reply Window ===");
        System.out.println("Reply from: " + event.getCompany());
        System.out.println("Project: " + event.getProject());
        System.out.println("TicketId: " + event.getTicketId());
        System.out.println("Message: " + event.getData());
        System.out.println("=====================================");
    }
}
*/