package com.kafka.company1consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Company1consumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Company1consumerApplication.class, args);
	}

}
