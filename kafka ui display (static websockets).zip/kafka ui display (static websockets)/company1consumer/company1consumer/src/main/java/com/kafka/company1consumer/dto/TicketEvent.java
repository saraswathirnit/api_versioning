package com.kafka.company1consumer.dto;

import java.io.Serializable;

public class TicketEvent implements Serializable {
    private String company;
    private String project;
    private String ticketId;
    private String data;

    // ✅ New fields for WebSocket routing
    private String targetSessionId;  // COMPAY2-STATIC-WSID-1 or COMPAY2-STATIC-WSID-2
    private String message;

    public TicketEvent() {
    }

    public TicketEvent(String company, String project, String ticketId, String data,
                       String targetSessionId, String message) {
        this.company = company;
        this.project = project;
        this.ticketId = ticketId;
        this.data = data;
        this.targetSessionId = targetSessionId;
        this.message = message;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getTargetSessionId() {
        return targetSessionId;
    }

    public void setTargetSessionId(String targetSessionId) {
        this.targetSessionId = targetSessionId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "TicketEvent{" +
                "company='" + company + '\'' +
                ", project='" + project + '\'' +
                ", ticketId='" + ticketId + '\'' +
                ", data='" + data + '\'' +
                ", targetSessionId='" + targetSessionId + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
