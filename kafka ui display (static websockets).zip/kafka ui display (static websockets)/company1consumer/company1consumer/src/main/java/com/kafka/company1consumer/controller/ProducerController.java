package com.kafka.company1consumer.controller;

import com.kafka.company1consumer.dto.TicketEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/Company1")  // 👈 Base path = http://localhost:8080/Company1
public class ProducerController {

    private final KafkaTemplate<String, TicketEvent> kafkaTemplate;

    @Value("${app.topic.produce2}")   // should be mapped to "company2-topic" in application.properties
    private String requestTopic;

    public ProducerController(KafkaTemplate<String, TicketEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    // 👇 POST JSON directly to http://localhost:8080/Company1
    @PostMapping
    public String produceMessage(@RequestBody TicketEvent event) {
        // Ensure mandatory fields
        if (event.getTicketId() == null || event.getTicketId().isBlank()) {
            event.setTicketId("ticket-" + UUID.randomUUID());
        }

        // Always enrich with Company1 info
        event.setCompany("Company1");
        if (event.getProject() == null || event.getProject().isBlank()) {
            event.setProject("ProjectFromCompany1");
        }

        // 🚫 Validate targetSessionId
        if (event.getTargetSessionId() == null || event.getTargetSessionId().isBlank()) {
            return "❌ Error: targetSessionId must be provided.";
        }

        // 🚀 Send to Kafka topic (company2-topic)
        kafkaTemplate.send(requestTopic, event.getTicketId(), event);

        return "✅ Sent from Company1 → Company2 (WSID: " 
               + event.getTargetSessionId() + "): " + event;
    }
}
