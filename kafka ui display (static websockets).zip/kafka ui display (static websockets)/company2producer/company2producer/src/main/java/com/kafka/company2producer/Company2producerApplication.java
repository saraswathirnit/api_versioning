package com.kafka.company2producer;

import com.kafka.company2producer.dto.TicketEvent;
import com.kafka.company2producer.service.ProducerService;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Company2producerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Company2producerApplication.class, args);
    }

    // ✅ Auto-run producer once the app starts
    @Bean
    public CommandLineRunner runner(ProducerService producerService) {
        return args -> {
            TicketEvent event = new TicketEvent();
            event.setCompany("Company2");
            event.setProject("Project4");
            event.setTicketId("ticket-3");
            event.setData("Auto-triggered data from Company2 -> Project4");

            // ✅ New required fields
            event.setTargetSessionId("COMPANY2-STATIC-WSID-1");
            event.setMessage("Auto message from Company2 to WSID-1");

            // ✅ uses sendEvent (standardized)
            producerService.sendEvent(event);
        };
    }
}
