package com.kafka.company2producer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kafka.company2producer.dto.TicketEvent;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.net.URI;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class WebSocketSessionManager extends TextWebSocketHandler {

    // 🔒 Allowed static WebSocket IDs
    private static final Set<String> ALLOWED_WS_IDS = Set.of(
        "COMPANY2-STATIC-WSID-1",
        "COMPANY2-STATIC-WSID-2"
    );

    // Map: id -> session
    private final Map<String, WebSocketSession> sessionMap = new ConcurrentHashMap<>();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String idParam = extractIdFromQuery(session);

        if (idParam != null && ALLOWED_WS_IDS.contains(idParam)) {
            sessionMap.put(idParam, session);
            session.sendMessage(new TextMessage("✅ Connected with ID: " + idParam));
        } else {
            session.sendMessage(new TextMessage("❌ Invalid WebSocket ID. Connection closed."));
            session.close(CloseStatus.NOT_ACCEPTABLE);
        }
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException {
        session.sendMessage(new TextMessage("Echo: " + message.getPayload()));
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        sessionMap.values().remove(session);
    }

    // 🔑 Utility method → Send event to its target WebSocket session
    public void sendToTargetSession(TicketEvent event) {
        String targetId = event.getTargetSessionId();
        WebSocketSession targetSession = sessionMap.get(targetId);

        if (targetSession != null && targetSession.isOpen()) {
            try {
                String json = objectMapper.writeValueAsString(event);
                targetSession.sendMessage(new TextMessage(json));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("⚠️ No open WebSocket session for ID: " + targetId);
        }
    }

    // ✅ Helper → extract ?id=... from URL query
    private String extractIdFromQuery(WebSocketSession session) {
        URI uri = session.getUri();
        if (uri == null || uri.getQuery() == null) return null;

        String[] params = uri.getQuery().split("&");
        for (String param : params) {
            if (param.startsWith("id=")) {
                return param.substring(3);
            }
        }
        return null;
    }
}
