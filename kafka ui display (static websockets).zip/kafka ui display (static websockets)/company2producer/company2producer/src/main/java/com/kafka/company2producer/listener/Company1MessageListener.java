package com.kafka.company2producer.listener;

import com.kafka.company2producer.dto.TicketEvent;
import com.kafka.company2producer.service.WebSocketSessionManager;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Company1MessageListener {

    private final WebSocketSessionManager webSocketSessionManager;

    public Company1MessageListener(WebSocketSessionManager webSocketSessionManager) {
        this.webSocketSessionManager = webSocketSessionManager;
    }

    @KafkaListener(
        topics = "${app.topic.consume2}",
        groupId = "company2-producer-group",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void listenFromCompany1(TicketEvent event) {
        System.out.println("=== Company2 Chat Window ===");
        System.out.println("From company: " + event.getCompany());
        System.out.println("Project: " + event.getProject());
        System.out.println("TicketId: " + event.getTicketId());
        System.out.println("Message: " + event.getData());
        System.out.println("Target Session: " + event.getTargetSessionId());
        System.out.println("=====================================");

        // ✅ Forward event to the correct WebSocket client
        webSocketSessionManager.sendToTargetSession(event);
    }
}
