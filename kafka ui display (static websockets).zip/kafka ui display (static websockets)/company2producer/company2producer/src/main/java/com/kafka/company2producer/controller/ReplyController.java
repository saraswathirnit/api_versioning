/*
package com.kafka.company2producer.controller;

import com.kafka.company2producer.dto.TicketEvent;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/reply")
public class ReplyController {

    private final KafkaTemplate<String, TicketEvent> kafkaTemplate;

    public ReplyController(KafkaTemplate<String, TicketEvent> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    
     * REST endpoint for sending manual replies from Company2 → Company1.
     * Example usage (PowerShell):
     * Invoke-WebRequest -Uri "http://localhost:8081/reply" -Method POST -Body "Hello from Company2 Reply!" -ContentType "text/plain"
     
    @PostMapping
    public String sendReply(@RequestBody String message) {
        TicketEvent reply = new TicketEvent();
        reply.setCompany("Company2");
        reply.setProject("Project2");
        reply.setTicketId("reply-" + UUID.randomUUID());
        reply.setData(message);

        // Send reply message to the request topic so Company1 will see it
        kafkaTemplate.send("company-topic", reply);

        return "✅ Reply sent to Company1 via Kafka: " + message;
    }
}
*/
